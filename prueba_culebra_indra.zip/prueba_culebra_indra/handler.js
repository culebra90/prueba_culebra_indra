'use strict';

const AWS = require('aws-sdk');
const ddb = new AWS.DynamoDB.DocumentClient();

var stado_servidor = 200
var mensaje = 'Hola a la prueba de indra - By Culebra'

module.exports.insertar = (event, context, callback) => { 

  var parametros = event['queryStringParameters']

  if(parametros===null){
    mensaje = 'Para insertar en la BD debe enviar el campo correspondiente'
    stado_servidor = 524
    let datos_salida = {'stado_servidor':stado_servidor,'mensaje':mensaje,'parametros':parametros,'datos':[],'tipo':'error'}
    salida_callback(callback,datos_salida)
  }else{
    if(typeof parametros['materia_id'] !== 'undefined' && typeof parametros['titulo'] !== 'undefined'){
      if(Number.isInteger(parseInt(parametros['materia_id']))){

        leer_datos(parametros['materia_id']).then(function(datos) {
  
          if(typeof datos.Item !== 'undefined'){
            stado_servidor = 524
            let datos_salida = {'stado_servidor':stado_servidor,'mensaje':'Ya existe una materia_id con ese ID','parametros':parametros,'tipo':'error'}
            salida_callback(callback,datos_salida)
          }else{          
            grabar_dynamodb(parametros['titulo'],parametros['materia_id']).then(() => {      
              let datos_salida = {'stado_servidor':stado_servidor,'mensaje':'Registro Guardado Correctamente','parametros':parametros,'tipo':'insertar'}
              salida_callback(callback,datos_salida)
            }).catch((err) => {      
              errorResponse(err.message, context.awsRequestId, callback,parametros)
            }); 
          }
  
        }).catch((err) => {      
          errorResponse(err.message, context.awsRequestId, callback,parametros)
        }); 
         
      }else{
        stado_servidor = 524
        let datos_salida = {'stado_servidor':stado_servidor,'mensaje':'materia_id no es numero entero','parametros':parametros,'tipo':'error'}
        salida_callback(callback,datos_salida)
      }
    }else{
      stado_servidor = 524
      let datos_salida = {'stado_servidor':stado_servidor,'mensaje':'Debes enviar los parametros adecuados para añadir a la BD','parametros':parametros,'tipo':'error'}
      salida_callback(callback,datos_salida)
    }
  } 
};

module.exports.obtener = (event, context, callback) => { 
  
  var parametros = event['queryStringParameters']

  if(parametros===null){
    mensaje = 'Para buscar en la BD debe enviar el campo correspondiente'
    stado_servidor = 524
    let datos_salida = {'stado_servidor':stado_servidor,'mensaje':mensaje,'parametros':parametros,'datos':[],'tipo':'error'}
    salida_callback(callback,datos_salida)
  }else{
    if(typeof parametros['materia_id'] !== 'undefined'){
      if(Number.isInteger(parseInt(parametros['materia_id']))){
        leer_datos(parametros['materia_id']).then(function(datos) {
          mensaje = (typeof datos.Item !== 'undefined') ? 'Datos encontrados' : 'No se encontraron datos' 
          let datos_salida = {'stado_servidor':stado_servidor,'mensaje':mensaje,'parametros':parametros,'busqueda':datos.Item,'tipo':'busqueda'}
          salida_callback(callback,datos_salida)
        }).catch((err) => {      
          errorResponse(err.message, context.awsRequestId, callback,parametros)
        });   
      }else{
        mensaje = 'materia_id debe ser numero entero'
        stado_servidor = 524
        let datos_salida = {'stado_servidor':stado_servidor,'mensaje':mensaje,'parametros':parametros,'datos':[],'tipo':'error'}
        salida_callback(callback,datos_salida)    
      }   
    }else if(typeof parametros['star_wars'] !== 'undefined'){
      
      if(Number.isInteger(parseInt(parametros['star_wars']))){
        const fetch = require('node-fetch');

        fetch('https://swapi.dev/api/starships/'+parametros['star_wars']+'/')
        .then(valor => valor.json())
        .then( json => {
          
          if(json.detail=='Not found'){
            stado_servidor = 524
            let datos_salida = {'stado_servidor':stado_servidor,'mensaje':'Star War NO encontrado','parametros':parametros,'busqueda':json,'tipo':'star_wars'}
            salida_callback(callback,datos_salida) 
          }else{
            stado_servidor = 200
            let datos_salida = {'stado_servidor':stado_servidor,'mensaje':'Star War encontrado','parametros':parametros,'busqueda':json,'tipo':'star_wars'}
            salida_callback(callback,datos_salida) 
          }
          
        });
      }else{
        mensaje = 'star_wars debe ser numero entero'
        stado_servidor = 524
        let datos_salida = {'stado_servidor':stado_servidor,'mensaje':mensaje,'parametros':parametros,'datos':[],'tipo':'error'}
        salida_callback(callback,datos_salida)
      }     

    }else{
      mensaje = 'Debe enviar los parametros correspondientes'
      stado_servidor = 524
      let datos_salida = {'stado_servidor':stado_servidor,'mensaje':mensaje,'parametros':parametros,'datos':[],'tipo':'error'}
      salida_callback(callback,datos_salida) 
    }
  }  
};

function grabar_dynamodb(titulo, materia_id) {
  return ddb.put({
      TableName: 'materias',
      Item: {
          'materia_id': parseInt(materia_id),
          'titulo': titulo          
      },
  }).promise();
}

function leer_datos(clave){
  return ddb.get({
    TableName: 'materias',
    Key: {
      materia_id: parseInt(clave)
    }
  }).promise();    
}

function errorResponse(errorMessage, awsRequestId, callback,parametros) {
  callback(null, {
    statusCode: 500,
    body: JSON.stringify({
      Error: errorMessage,
      Reference: awsRequestId,
      parametros: parametros
    })
  });
}

function salida_callback(callback,datos){

  let array_body = (datos.tipo=='error' || datos.tipo=='insertar')
    ? {'mensaje':datos.mensaje,'parametros':datos.parametros}
    : {'mensaje':datos.mensaje,'parametros':datos.parametros,'busqueda':datos.busqueda}
  
  callback(null, {statusCode: datos.stado_servidor, body: JSON.stringify(array_body,null,2)});
}